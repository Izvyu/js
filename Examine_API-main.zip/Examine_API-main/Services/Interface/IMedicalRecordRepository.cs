﻿


namespace TodoApi2
{
    public interface IMedicalRecordRepository
    {
        ResultDTO GetData(MedicalRecord c);

    }
}
