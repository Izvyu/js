﻿


namespace TodoApi2
{
    public interface IPersonItemRepository
    {
        ResultDTO GetData(PersonItem c);



    }
}
