﻿


namespace TodoApi2
{
    public interface ICheckItemRepository
    {
        ResultDTO GetData(CheckItem c);

    }
}
