﻿


namespace TodoApi2
{
    public interface ICheckProjectNameListRepository
    {
        ResultDTO GetData(CheckProjectNameList c);



    }
}
