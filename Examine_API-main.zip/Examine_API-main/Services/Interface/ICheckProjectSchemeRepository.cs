﻿


namespace TodoApi2
{
    public interface ICheckProjectSchemeRepository
    {
        ResultDTO GetData(CheckProject c);



    }
}
