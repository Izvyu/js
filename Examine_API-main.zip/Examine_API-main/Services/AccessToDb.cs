namespace TodoApi2
{

    public class AccessToDb
    {
        public static string? ConnectionString { get; set; }
        public static string? ConnectionString_Medirep { get; set; }
    }
}