﻿

namespace TodoApi2
{
    public class CheckProjectNameList
    {
        public string? BarCodeStr { get; set; }
        public string? QueryString { get; set; }

    }
}
