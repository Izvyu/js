﻿namespace TodoApi2
{
    public class MedicalRecord
    {
        public string? StartDate { get; set; }
    }
}