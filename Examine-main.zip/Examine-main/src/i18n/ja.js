//大小寫需一致
const ja_JP = { 'app.learn': '学び {name}',
"app.Salmon":"{name} イカ" ,
"app.loginMessage":"アカウントとパスワードを入力してください",
"username":"アカウント",
"password":"パスワード"
,"app.Languages": "言語"
,"app.Colors": "色"
};
export default ja_JP;